<?php
	$con = mysqli_connect("localhost", "root", "", "realestate") or die ("Database Connection Failed!!!");
?>